THE KEYBOARD LOCKER

1. How to use

This simple program will disable the keyboard when you
press Ctrl+Alt+L.

Once the keyboard is locked, you can type in "unlock" to
unlock it.

You can enable balloon notifications when the keyboard is
locked or unlocked by right clicking on the tray icon
(looks like a keyboard) and clicking on "Show tray
notifications."

For more information on usage of this program, please see
the original How-To Geek post at:
http://www.howtogeek.com/howto/11570/disable-the-keyboard-with-a-keyboard-shortcut-in-windows/


2. About this program

This program is an AutoHotKey script compiled to an EXE
file.

The script was originally written by Lexikos and posted
to the AutoHotKey forums at:
http://www.autohotkey.com/forum/post-147849.html#147849

Lexicos generously allowed us to modify and redistribute
his script. Modifications were made by Trevor Bekolay for
the How-To Geek website at:
http://www.howtogeek.com